from backend.database import engine, Base, get_db
from backend import models

from fastapi import (
    FastAPI,
    UploadFile,
    File,
    Depends,
    HTTPException
)

from fastapi.middleware.cors import CORSMiddleware

from fastapi.security import (
    HTTPBearer,
    HTTPAuthorizationCredentials
)

from sqlalchemy.orm import Session

from backend.schemas import (
    UserCreate,
    UserResponse,
    LoginRequest
)

from backend.auth import (
    hash_password,
    verify_password,
    create_access_token,
    decode_access_token
)

import os
import cv2


# =========================================================
# CREATE DATABASE TABLES
# =========================================================

Base.metadata.create_all(bind=engine)


# =========================================================
# CREATE FASTAPI APPLICATION
# =========================================================

app = FastAPI(
    title="VisionInspect AI",
    description="Manufacturing Defect Detection & Quality Inspection System",
    version="1.0.0"
)


# =========================================================
# CORS CONFIGURATION
# Allows Next.js frontend to communicate with FastAPI
# =========================================================

app.add_middleware(
    CORSMiddleware,
    allow_origins=[
        "http://localhost:3000",
        "http://127.0.0.1:3000"
    ],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# =========================================================
# JWT SECURITY
# =========================================================

security = HTTPBearer()


# =========================================================
# FOLDERS
# =========================================================

UPLOAD_FOLDER = "uploads"
PROCESSED_FOLDER = "processed"

os.makedirs(
    UPLOAD_FOLDER,
    exist_ok=True
)

os.makedirs(
    PROCESSED_FOLDER,
    exist_ok=True
)


# =========================================================
# HOME API
# =========================================================

@app.get("/")
def home():

    return {
        "message": "VisionInspect AI API is running"
    }


# =========================================================
# IMAGE UPLOAD AND PREPROCESSING API
# =========================================================

@app.post("/upload")
async def upload_image(
    file: UploadFile = File(...)
):

    # Check file type
    if not file.content_type or not file.content_type.startswith("image/"):

        raise HTTPException(
            status_code=400,
            detail="Please upload a valid image file"
        )

    # Save uploaded image
    file_path = os.path.join(
        UPLOAD_FOLDER,
        file.filename
    )

    with open(file_path, "wb") as buffer:

        buffer.write(
            await file.read()
        )

    # Read image using OpenCV
    image = cv2.imread(file_path)

    # Check whether image was read successfully
    if image is None:

        raise HTTPException(
            status_code=400,
            detail="Could not read the uploaded image"
        )

    # Resize image to 224 x 224
    resized_image = cv2.resize(
        image,
        (224, 224)
    )

    # Convert image to grayscale
    gray_image = cv2.cvtColor(
        resized_image,
        cv2.COLOR_BGR2GRAY
    )

    # Create processed image path
    processed_path = os.path.join(
        PROCESSED_FOLDER,
        "processed_" + file.filename
    )

    # Save processed image
    cv2.imwrite(
        processed_path,
        gray_image
    )

    # Return result
    return {

        "message":
            "Image uploaded and preprocessed successfully",

        "filename":
            file.filename,

        "original_path":
            file_path,

        "processed_path":
            processed_path,

        "image_size":
            "224x224",

        "preprocessing":
            "Resize + Grayscale"
    }


# =========================================================
# USER REGISTRATION API
# =========================================================

@app.post(
    "/register",
    response_model=UserResponse
)
def register_user(
    user: UserCreate,
    db: Session = Depends(get_db)
):

    # Check whether email already exists
    existing_user = db.query(
        models.User
    ).filter(
        models.User.email == user.email
    ).first()

    if existing_user:

        raise HTTPException(
            status_code=400,
            detail="Email already registered"
        )

    # Create new user
    new_user = models.User(

        name=user.name,

        email=user.email,

        hashed_password=hash_password(
            user.password
        ),

        role=user.role
    )

    # Save user to database
    db.add(new_user)

    db.commit()

    db.refresh(new_user)

    return new_user


# =========================================================
# USER LOGIN API
# =========================================================

@app.post("/login")
def login_user(
    user: LoginRequest,
    db: Session = Depends(get_db)
):

    # Find user using email
    existing_user = db.query(
        models.User
    ).filter(
        models.User.email == user.email
    ).first()

    # User does not exist
    if not existing_user:

        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    # Check password
    password_correct = verify_password(
        user.password,
        existing_user.hashed_password
    )

    # Password is incorrect
    if not password_correct:

        raise HTTPException(
            status_code=401,
            detail="Invalid email or password"
        )

    # Create JWT token
    access_token = create_access_token(

        data={

            "sub":
                str(existing_user.id),

            "email":
                existing_user.email,

            "role":
                existing_user.role
        }
    )

    # Return login response
    return {

        "message":
            "Login successful",

        "access_token":
            access_token,

        "token_type":
            "bearer",

        "user": {

            "id":
                existing_user.id,

            "name":
                existing_user.name,

            "email":
                existing_user.email,

            "role":
                existing_user.role
        }
    }


# =========================================================
# PROTECTED PROFILE API
# =========================================================

@app.get("/profile")
def get_profile(

    credentials: HTTPAuthorizationCredentials =
        Depends(security)
):

    # Get token from Authorization header
    token = credentials.credentials

    try:

        # Decode and verify JWT token
        payload = decode_access_token(token)

        return {

            "message":
                "Authentication successful",

            "user_id":
                payload.get("sub"),

            "email":
                payload.get("email"),

            "role":
                payload.get("role")
        }

    except Exception:

        raise HTTPException(
            status_code=401,
            detail="Invalid or expired token"
        )